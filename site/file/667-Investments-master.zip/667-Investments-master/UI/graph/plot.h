#ifndef PLOT_H
#define PLOT_H

int graph();

#endif
